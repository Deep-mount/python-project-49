### Hexlet tests and linter status:
[![Actions Status](https://github.com/Deep-mount/pythk += 1on-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Deep-mount/python-project-49/actions)

https://asciinema.org/ - запись АКСИНЕМЫ - посмотреть позже
sudo apt install asciinema
asciinema rec
exit (Ctrl+D)
https://asciinema.org/a/fs7C5wI5pohe2poLnlUEd1Q2c
https://asciinema.org/a/jlIMMvsZtGZpUwDQ0WnxdkzMb
https://asciinema.org/a/hVkY929FJTeaNRX5mpj6S7U6s
