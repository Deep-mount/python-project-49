### Hexlet tests and linter status:
[![Actions Status](https://github.com/Deep-mount/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Deep-mount/python-project-49/actions)

https://asciinema.org/ - запись АКСИНЕМЫ - посмотреть позже
sudo apt install asciinema
asciinema rec
exit (Ctrl+D)
https://asciinema.org/a/fs7C5wI5pohe2poLnlUEd1Q2c

